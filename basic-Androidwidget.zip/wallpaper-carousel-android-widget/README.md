Wally: A working Android wallpaper carousel with no ads.

[![Build](https://github.com/Fector101/wallpaper-carousel/actions/workflows/android.yml/badge.svg)](https://github.com/Fector101/wallpaper-carousel/actions/workflows/android.yml)

[APK Download](https://github.com/Fector101/wallpaper-carousel/actions/runs/20020694562/artifacts/4794668313)

- Every 2mins wallpaper switches to a new image already provided by user.
